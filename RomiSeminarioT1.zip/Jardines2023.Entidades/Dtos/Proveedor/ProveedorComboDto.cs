﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jardines2023.Entidades.Dtos.Proveedor
{
    public class ProveedorComboDto
    {
        public string NombreProveedor { get; set; }
        public int ProveedorId { get; set; }

    }
}
