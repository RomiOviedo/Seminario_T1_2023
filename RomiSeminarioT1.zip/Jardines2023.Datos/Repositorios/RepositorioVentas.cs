﻿using Jardines2023.Comun.Interfaces;
using Jardines2023.Entidades.Dtos.Producto;
using Jardines2023.Entidades.Dtos.Venta;
using Jardines2023.Entidades.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jardines2023.Datos.Repositorios
{
    public class RepositorioVentas : IRepositorioVentas
    {
        private readonly string cadenaConexion;
        public RepositorioVentas()
        {
            cadenaConexion = ConfigurationManager.ConnectionStrings["MiConexion"].ToString();

        }
        public List<VentaDto> GetVentas()
        {
            try
            {
                List<VentaDto> lista = new List<VentaDto>();

                using (var conn = new SqlConnection(cadenaConexion))
                {
                    conn.Open();

                    string selectQuery = "SELECT VentaId, FechaVenta, ClienteId, Total FROM Ventas";
                       // ORDER BY VentaId";
                    using (var comando = new SqlCommand(selectQuery, conn))
                    {
                        using (var reader = comando.ExecuteReader()) // traigo todos los registros
                        {
                            while (reader.Read())
                            {
                                var ventasDto = new VentaDto()
                                {
                                    VentaId = reader.GetInt32(0),
                                    FechaVenta = reader.GetDateTime(1),
                                    ClienteId = reader.GetInt32(2),
                                    NombreCliente=reader.GetString(3),
                                    Total = reader.GetDecimal(4)


                                };

                                
                                //var ventasDto = ConstruirVentaDto(reader);
                               lista.Add(ventasDto);
                            }
                        }
                    }
                }
                return lista;
            }
            catch (Exception)
            {

                throw;
            }

        }

        private VentaDto ConstruirVentaDto(SqlDataReader reader)
        {
            return new VentaDto()
            {
                VentaId = reader.GetInt32(0),
                FechaVenta = reader.GetDateTime(1),
                ClienteId = reader.GetInt32(2),
                Total = reader.GetDecimal(3)
            };

        }
    }
}
