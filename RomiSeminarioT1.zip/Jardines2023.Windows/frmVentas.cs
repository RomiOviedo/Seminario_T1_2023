﻿using Jardines2023.Entidades.Dtos.Venta;
using Jardines2023.Servicios.Interfaces;
using Jardines2023.Servicios.Servicios;
using Jardines2023.Windows.Helpers;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Jardines2023.Windows
{
    public partial class frmVentas : Form
    {
        private readonly IServiciosVentas _serviciosVentas;
        public frmVentas()
        {
            InitializeComponent();

            _serviciosVentas = new ServiciosVentas();

        }
        private List<VentaDto> lista;

        private void frmVentas_Load(object sender, EventArgs e)
        {
            try
            {
               lista = _serviciosVentas.GetVentas();
                MostrarDatosEnGrilla();

            }
            catch (Exception)
            {

                throw;
            }

        }
        private void MostrarDatosEnGrilla()
        {
            GridHelper.LimpiarGrilla(dgvDatosVentas);

            foreach (var venta in lista)
            {
                var r = GridHelper.ConstruirFila(dgvDatosVentas); //TRAIGO LA VENTA
                GridHelper.SetearFila(r, venta);            //PONGO LOS DATOS DE LA VENTA EN LA FILA
                GridHelper.AgregarFila(dgvDatosVentas, r);        // AGREGO  LA FILA A LA GRILLA
            }
        }



        private void tsbCerrar_Click(object sender, EventArgs e)
        {
            Close();

        }
    }

}
